<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Cross Linking for Magento 2
 */

namespace Amasty\CrossLinks\Model\LinkType\Processor;

use Amasty\CrossLinks\Model\Link;
use Amasty\CrossLinks\Model\Source\ReferenceType;

class CustomLinkProcessor implements LinkTypeProcessorInterface
{
    /**
     * @var Link
     */
    private $link;

    public function __construct(
        Link $link
    ) {
        $this->link = $link;
    }

    public function getTypeCode(): int
    {
        return ReferenceType::REFERENCE_TYPE_CUSTOM;
    }

    public function getStyleClass(): string
    {
        return '';
    }

    public function getBlockClass(): string
    {
        return '';
    }

    public function getPickerBlockData(): array
    {
        return [];
    }

    public function getResource(string $referenceResource)
    {
        return $this->link->getProduct($referenceResource);
    }

    public function getLinkUrl(string $referenceResource): string
    {
        return $this->link->getCustomUrl($referenceResource);
    }

    public function getResourceTextKey(): string
    {
        return '';
    }
}
