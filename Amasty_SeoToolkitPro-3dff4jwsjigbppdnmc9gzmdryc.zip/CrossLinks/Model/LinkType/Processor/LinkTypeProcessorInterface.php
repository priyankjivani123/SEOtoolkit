<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Cross Linking for Magento 2
 */

namespace Amasty\CrossLinks\Model\LinkType\Processor;

interface LinkTypeProcessorInterface
{
    public function getTypeCode(): int;

    public function getStyleClass(): string;

    public function getBlockClass(): string;

    public function getPickerBlockData(): array;

    public function getResource(string $referenceResource);

    public function getLinkUrl(string $referenceResource): string;

    public function getResourceTextKey(): string;
}
