<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Cross Linking for Magento 2
 */

namespace Amasty\CrossLinks\Model;

use Amasty\CrossLinks\Model\ResourceModel\Link as LinkResource;
use Amasty\CrossLinks\Model\Source\ReferenceType;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Api\Data\CategoryInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;

class Link extends AbstractModel implements \Amasty\CrossLinks\Api\LinkInterface
{
    public const DEFAULT_LINK_URL = '#';
    public const STATUS_INACTIVE = 0;
    public const STATUS_ACTIVE = 1;

    /**
     * @var null[]|CategoryInterface[]
     */
    private $categories = [];

    /**
     * @var null[]|ProductInterface[]
     */
    private $products = [];

    /**
     * @var \Amasty\CrossLinks\Helper\Data
     */
    protected $_helper;

    /**
     * @var array
     */
    protected $_entityOrderData = [];

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * AbstractGiftCardEntity constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Amasty\CrossLinks\Helper\Data $helper
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Amasty\CrossLinks\Helper\Data $helper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        ?\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        ?\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        $this->_helper = $helper;
        $this->storeManager = $storeManager;
        $this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(LinkResource::class);
    }

    /**
     * @param string $title
     * @return $this
     */
    public function setTitle($title)
    {
        $this->setData('title', $title);
        return $this;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->getData('title');
    }

    /**
     * @return array
     */
    public function getKeywords()
    {
        return explode("\r\n", $this->getData('keywords'));
    }

    /**
     * @param $innerText
     * @param string|null $linkUrl
     * @return string
     */
    public function getLinkHtml($innerText, ?string $linkUrl = null)
    {
        $link = $linkUrl ?? $this->getLinkUrl();
        return '<a href="' . $link . '" title="' . $this->getTitle() . '"'
            . ($this->getIsNofollow() ? ' rel="nofollow"' : '')
            . ' target="' . $this->getLinkTarget() . '"'
            . '>' . $innerText . '</a>';
    }

    /**
     * @return string
     */
    public function getLinkUrl()
    {
        switch ($this->getReferenceType()) {
            case ReferenceType::REFERENCE_TYPE_CUSTOM:
                $uri = $this->getCustomUrl();
                break;
            case ReferenceType::REFERENCE_TYPE_PRODUCT:
                $uri = $this->getProductUrl();
                break;
            case ReferenceType::REFERENCE_TYPE_CATEGORY:
                $uri = $this->getCategoryUrl();
                break;
            default:
                $uri = self::DEFAULT_LINK_URL;
        }

        return $uri;
    }

    /**
     * @return string
     */
    public function getCustomUrl(?string $referenceResource = null): string
    {
        $reference = $referenceResource ?? $this->getReferenceResource();

        return strpos($reference, 'http') === 0 ?
            $reference
            : $this->storeManager->getStore()->getBaseUrl() . trim($reference, '/');
    }

    /**
     * @param string|null $referenceResource
     * @return ProductInterface|null
     */
    public function getProduct(?string $referenceResource = null): ?ProductInterface
    {
        $id = $referenceResource ?? $this->getReferenceResource();
        if (!isset($this->products[$id])) {
            try {
                $this->products[$id] = $this->productRepository->getById($id);
            } catch (NoSuchEntityException $e) {
                $this->products[$id] = null;
            }
        }

        return $this->products[$id];
    }

    /**
     * @param string|null $referenceResource
     * @return CategoryInterface|null
     */
    public function getCategory(?string $referenceResource = null): ?CategoryInterface
    {
        $id = $referenceResource ?? $this->getReferenceResource();
        if (!isset($this->categories[$id])) {
            try {
                $this->categories[$id] = $this->categoryRepository->get($id);
            } catch (NoSuchEntityException $e) {
                $this->categories[$id] = null;
            }
        }

        return $this->categories[$id];
    }

    public function getProductUrl(?string $referenceResource = null): string
    {
        $productUrl = self::DEFAULT_LINK_URL;
        if ($product = $this->getProduct($referenceResource)) {
            $productUrl = $product->getProductUrl();
        }

        return $productUrl;
    }

    public function getCategoryUrl(?string $referenceResource = null): string
    {
        $categoryUrl = self::DEFAULT_LINK_URL;
        if ($category = $this->getCategory($referenceResource)) {
            $categoryUrl = $category->getUrl();
        }

        return $categoryUrl;
    }
}
