<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Magento 2 Base Package
 */

namespace Amasty\Base\Model\System\Message\DisplayValidator;

interface DisplayValidatorInterface
{
    public function needToShow(): bool;
}
